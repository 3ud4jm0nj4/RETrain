This set of examples were written by Bill Cravener.

Bill is a professional programmer who earns his living writing machine code
to control industrial machinery and this precision and experience shows in
his examples.

The style is very crisp and clear and demonstrates how to write simple reliable
code in a minimalist manner, one of the hallmarks of a professional.

If you live in the north East of the US, you may see this big guy on a slick
looking black Yamaha travelling past some weekend, good chance its Bill.




